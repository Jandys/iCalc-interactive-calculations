<?php

namespace icalc\model;

class Product extends BaseDatabaseModel
{


}