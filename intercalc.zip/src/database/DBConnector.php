<?php

namespace icalc\db;

class DBConnector
{

    private $wpdb;

    public function __construct()
    {
//        console_log("inside construct");
//        $this->init();
    }

    public function callMe(){
        console_log("call me");
    }

    public function createTable($tableName, $additionalSettings){
        console_log("create table");

        $table_name = $this->wpdb->prefix . $tableName;


        $sql = "CREATE TABLE IF NOT EXISTS %s %s";

        $args = array($table_name,$additionalSettings);

        return $this->prepareQuery($sql,$args);
    }



    public function prepareQuery($sql, $args)
    {
        console_log("prepare query");
        return $this->wpdb->prepare($sql, $args);
    }


    public function test($sql, $args)
    {
        global $wpdb;

    }


    public function init(){
        console_log("inside init");
        $dbuser     = defined( 'DB_USER' ) ? DB_USER : '';
        $dbpassword = defined( 'DB_PASSWORD' ) ? DB_PASSWORD : '';
        $dbname     = defined( 'DB_NAME' ) ? DB_NAME : '';
        $dbhost     = defined( 'DB_HOST' ) ? DB_HOST : '';
        $this->wpdb =  new wpdb($dbuser,$dbpassword,$dbname,$dbhost);
    }
}