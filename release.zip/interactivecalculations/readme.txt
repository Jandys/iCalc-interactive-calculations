=== Interactive Calculations ===
Contributors: @jandys
Tags: interactive, calculations, forms, costs, bmi
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html

Interactive Calculations is a powerful and easy-to-use plugin for WordPress websites. It allows you to create beautiful and responsive calculators, giving your users the power to make instant calculations on your site. From simple arithmetic to complex formulas, Interactive Calculations can handle it all.